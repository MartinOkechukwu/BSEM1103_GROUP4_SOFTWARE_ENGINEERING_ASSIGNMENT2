# CityCare Hospital - Flutter App

Flutter UI prototype of a hospital management system (PROG 202 - Software Engineering, Assignment 2).

## Features
- 13 interconnected screens: Splash, Login, Register, Home, Doctors, Doctor Details, Book Appointment, Appointments, Profile, Medical Records, Departments, Emergency, Settings
- Named routes, navigation stack, data passing (Doctor object), Bottom Navigation Bar, Drawer, TabBar
- Forms with TextFormField, Dropdowns, TextEditingController and validation
- Reusable widgets: CustomButton, CustomTextField, DoctorCard, AppointmentCard, ServiceTile, AppDrawer

## Folder structure
```
lib/
  main.dart
  routes/    app_routes.dart
  models/    doctor.dart, appointment.dart
  data/      dummy_data.dart
  utils/     theme.dart, validators.dart
  widgets/   reusable widgets
  screens/   all screens
```

## Run
```
flutter pub get
flutter run
```
Login accepts any valid email and a password of 6+ characters (no backend yet).
