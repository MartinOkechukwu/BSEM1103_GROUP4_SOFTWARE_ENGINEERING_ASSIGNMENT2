import 'package:flutter/material.dart';
import 'routes/app_routes.dart';
import 'utils/theme.dart';

void main() => runApp(const HospitalApp());

class HospitalApp extends StatelessWidget {
  const HospitalApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CityCare Hospital',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      initialRoute: AppRoutes.splash,
      routes: AppRoutes.routes,
    );
  }
}
