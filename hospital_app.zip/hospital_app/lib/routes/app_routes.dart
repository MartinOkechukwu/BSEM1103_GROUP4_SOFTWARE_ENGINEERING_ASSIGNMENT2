import 'package:flutter/material.dart';
import '../screens/splash_screen.dart';
import '../screens/login_screen.dart';
import '../screens/register_screen.dart';
import '../screens/main_shell.dart';
import '../screens/doctor_details_screen.dart';
import '../screens/book_appointment_screen.dart';
import '../screens/records_screen.dart';
import '../screens/departments_screen.dart';
import '../screens/emergency_screen.dart';
import '../screens/settings_screen.dart';

/// Central place for all named routes.
class AppRoutes {
  static const splash = '/';
  static const login = '/login';
  static const register = '/register';
  static const home = '/home';
  static const doctorDetails = '/doctor-details';
  static const bookAppointment = '/book-appointment';
  static const records = '/records';
  static const departments = '/departments';
  static const emergency = '/emergency';
  static const settings = '/settings';

  static final Map<String, WidgetBuilder> routes = {
    splash: (_) => const SplashScreen(),
    login: (_) => const LoginScreen(),
    register: (_) => const RegisterScreen(),
    home: (_) => const MainShell(),
    doctorDetails: (_) => const DoctorDetailsScreen(),
    bookAppointment: (_) => const BookAppointmentScreen(),
    records: (_) => const RecordsScreen(),
    departments: (_) => const DepartmentsScreen(),
    emergency: (_) => const EmergencyScreen(),
    settings: (_) => const SettingsScreen(),
  };
}
