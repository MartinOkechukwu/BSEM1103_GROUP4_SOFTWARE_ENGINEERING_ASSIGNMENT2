import 'package:flutter/material.dart';
import '../models/doctor.dart';
import '../models/appointment.dart';

/// Dummy data used in place of a real backend (prototype stage).
class AppData {
  static const List<Doctor> doctors = [
    Doctor(
      name: 'Dr. Aminata Kamara',
      specialty: 'Cardiology',
      experienceYears: 12,
      rating: 4.8,
      bio: 'Heart specialist focusing on prevention, hypertension and cardiac care.',
      imageUrl: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400',
    ),
    Doctor(
      name: 'Dr. Mohamed Bangura',
      specialty: 'Pediatrics',
      experienceYears: 9,
      rating: 4.7,
      bio: 'Provides child healthcare, vaccinations and growth monitoring.',
      imageUrl: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400',
    ),
    Doctor(
      name: 'Dr. Fatmata Sesay',
      specialty: 'Gynecology',
      experienceYears: 15,
      rating: 4.9,
      bio: "Women's health, antenatal care and safe delivery services.",
      imageUrl: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=400',
    ),
    Doctor(
      name: 'Dr. Ibrahim Conteh',
      specialty: 'General Medicine',
      experienceYears: 7,
      rating: 4.5,
      bio: 'General consultations, diagnosis and treatment of common illnesses.',
      imageUrl: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=400',
    ),
    Doctor(
      name: 'Dr. Mariatu Koroma',
      specialty: 'Dermatology',
      experienceYears: 6,
      rating: 4.6,
      bio: 'Skin, hair and nail conditions, including allergy treatment.',
      imageUrl: 'https://images.unsplash.com/photo-1651008376811-b90baee60c1f?w=400',
    ),
  ];

  static const List<Map<String, dynamic>> departments = [
    {'name': 'Cardiology', 'icon': Icons.favorite},
    {'name': 'Pediatrics', 'icon': Icons.child_care},
    {'name': 'Gynecology', 'icon': Icons.pregnant_woman},
    {'name': 'General Medicine', 'icon': Icons.medical_services},
    {'name': 'Dermatology', 'icon': Icons.healing},
    {'name': 'Laboratory', 'icon': Icons.science},
    {'name': 'Pharmacy', 'icon': Icons.local_pharmacy},
    {'name': 'Radiology', 'icon': Icons.monitor_heart},
  ];

  static const List<String> timeSlots = [
    '08:00 AM', '09:00 AM', '10:00 AM', '11:00 AM',
    '02:00 PM', '03:00 PM', '04:00 PM',
  ];

  static const List<Map<String, String>> prescriptions = [
    {'title': 'Amoxicillin 500mg', 'detail': '3 times daily for 5 days - Dr. Ibrahim Conteh'},
    {'title': 'Paracetamol 500mg', 'detail': 'When needed for pain - Dr. Ibrahim Conteh'},
    {'title': 'Vitamin C', 'detail': 'Once daily for 14 days - Dr. Fatmata Sesay'},
  ];

  static const List<Map<String, String>> labResults = [
    {'title': 'Malaria Test', 'detail': 'Negative - 02 Nov 2026'},
    {'title': 'Blood Sugar', 'detail': '5.4 mmol/L (Normal) - 02 Nov 2026'},
    {'title': 'Full Blood Count', 'detail': 'Normal - 20 Oct 2026'},
  ];

  /// Shared, observable list so every screen updates when an appointment changes.
  static final ValueNotifier<List<Appointment>> appointments =
      ValueNotifier<List<Appointment>>([
    const Appointment(
      doctorName: 'Dr. Aminata Kamara',
      specialty: 'Cardiology',
      patientName: 'Martin',
      date: '20 Nov 2026',
      time: '10:00 AM',
      reason: 'Routine heart check-up',
    ),
    const Appointment(
      doctorName: 'Dr. Ibrahim Conteh',
      specialty: 'General Medicine',
      patientName: 'Martin',
      date: '02 Nov 2026',
      time: '09:00 AM',
      reason: 'Fever and headache',
      status: 'Completed',
    ),
  ]);

  static void addAppointment(Appointment a) {
    appointments.value = [a, ...appointments.value];
  }

  static void cancelAppointment(int index) {
    final list = [...appointments.value];
    list[index] = list[index].copyWith(status: 'Cancelled');
    appointments.value = list;
  }
}
