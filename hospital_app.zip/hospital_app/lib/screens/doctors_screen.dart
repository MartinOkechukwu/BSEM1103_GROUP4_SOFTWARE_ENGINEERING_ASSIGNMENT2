import 'package:flutter/material.dart';
import '../data/dummy_data.dart';
import '../models/doctor.dart';
import '../routes/app_routes.dart';
import '../widgets/doctor_card.dart';

class DoctorsScreen extends StatefulWidget {
  const DoctorsScreen({super.key});

  @override
  State<DoctorsScreen> createState() => _DoctorsScreenState();
}

class _DoctorsScreenState extends State<DoctorsScreen> {
  final _searchController = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final List<Doctor> filtered = AppData.doctors
        .where((d) =>
            d.name.toLowerCase().contains(_query.toLowerCase()) ||
            d.specialty.toLowerCase().contains(_query.toLowerCase()))
        .toList();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: TextField(
            controller: _searchController,
            onChanged: (v) => setState(() => _query = v),
            decoration: const InputDecoration(
              hintText: 'Search by name or specialty',
              prefixIcon: Icon(Icons.search),
            ),
          ),
        ),
        Expanded(
          child: filtered.isEmpty
              ? const Center(child: Text('No doctors found'))
              : ListView.builder(
                  itemCount: filtered.length,
                  itemBuilder: (context, i) => DoctorCard(
                    doctor: filtered[i],
                    // Passing data between screens
                    onTap: () => Navigator.pushNamed(
                      context,
                      AppRoutes.doctorDetails,
                      arguments: filtered[i],
                    ),
                  ),
                ),
        ),
      ],
    );
  }
}
