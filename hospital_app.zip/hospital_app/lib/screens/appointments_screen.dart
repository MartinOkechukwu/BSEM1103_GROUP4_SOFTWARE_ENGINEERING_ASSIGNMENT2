import 'package:flutter/material.dart';
import '../data/dummy_data.dart';
import '../models/appointment.dart';
import '../routes/app_routes.dart';
import '../widgets/appointment_card.dart';
import '../widgets/custom_button.dart';

class AppointmentsScreen extends StatelessWidget {
  const AppointmentsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: CustomButton(
            label: 'Book New Appointment',
            icon: Icons.add,
            onPressed: () => Navigator.pushNamed(context, AppRoutes.bookAppointment),
          ),
        ),
        Expanded(
          child: ValueListenableBuilder<List<Appointment>>(
            valueListenable: AppData.appointments,
            builder: (context, list, _) {
              if (list.isEmpty) {
                return const Center(child: Text('No appointments yet'));
              }
              return ListView.builder(
                itemCount: list.length,
                itemBuilder: (context, i) => AppointmentCard(
                  appointment: list[i],
                  onCancel: () => AppData.cancelAppointment(i),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
