import 'package:flutter/material.dart';
import '../models/doctor.dart';
import '../routes/app_routes.dart';
import '../utils/theme.dart';
import '../widgets/custom_button.dart';

class DoctorDetailsScreen extends StatelessWidget {
  const DoctorDetailsScreen({super.key});

  Widget _stat(IconData icon, String value, String label) {
    return Expanded(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14),
          child: Column(
            children: [
              Icon(icon, color: AppTheme.primary),
              const SizedBox(height: 4),
              Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
              Text(label, style: const TextStyle(fontSize: 12, color: Colors.grey)),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Receive the Doctor object passed from the previous screen
    final doctor = ModalRoute.of(context)!.settings.arguments as Doctor;

    return Scaffold(
      appBar: AppBar(title: const Text('Doctor Details')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            ClipOval(
              child: Image.network(
                doctor.imageUrl,
                width: 130,
                height: 130,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) =>
                    const CircleAvatar(radius: 65, child: Icon(Icons.person, size: 60)),
              ),
            ),
            const SizedBox(height: 12),
            Text(doctor.name,
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            Text(doctor.specialty, style: const TextStyle(color: AppTheme.primary)),
            const SizedBox(height: 16),
            Row(
              children: [
                _stat(Icons.star, '${doctor.rating}', 'Rating'),
                _stat(Icons.work, '${doctor.experienceYears} yrs', 'Experience'),
                _stat(Icons.people, '500+', 'Patients'),
              ],
            ),
            const SizedBox(height: 12),
            Align(
              alignment: Alignment.centerLeft,
              child: const Text('About',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 6),
            Text(doctor.bio),
            const SizedBox(height: 24),
            CustomButton(
              label: 'Book Appointment',
              icon: Icons.calendar_month,
              onPressed: () => Navigator.pushNamed(
                context,
                AppRoutes.bookAppointment,
                arguments: doctor,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
