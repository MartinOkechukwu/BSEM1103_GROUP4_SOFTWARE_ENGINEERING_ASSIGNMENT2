import 'package:flutter/material.dart';
import '../data/dummy_data.dart';
import '../models/appointment.dart';
import '../models/doctor.dart';
import '../routes/app_routes.dart';
import '../utils/validators.dart';
import '../widgets/custom_button.dart';
import '../widgets/custom_text_field.dart';

class BookAppointmentScreen extends StatefulWidget {
  const BookAppointmentScreen({super.key});

  @override
  State<BookAppointmentScreen> createState() => _BookAppointmentScreenState();
}

class _BookAppointmentScreenState extends State<BookAppointmentScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController(text: 'Martin');
  final _dateController = TextEditingController();
  final _reasonController = TextEditingController();
  Doctor? _selectedDoctor;
  String? _selectedTime;
  bool _initialised = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_initialised) {
      // Doctor is optional: it is passed only when coming from Doctor Details.
      final arg = ModalRoute.of(context)?.settings.arguments;
      if (arg is Doctor) _selectedDoctor = arg;
      _initialised = true;
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _dateController.dispose();
    _reasonController.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: now,
      firstDate: now,
      lastDate: now.add(const Duration(days: 90)),
    );
    if (picked != null) {
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      setState(() => _dateController.text =
          '${picked.day.toString().padLeft(2, '0')} ${months[picked.month - 1]} ${picked.year}');
    }
  }

  void _submit() {
    if (_formKey.currentState!.validate()) {
      AppData.addAppointment(Appointment(
        doctorName: _selectedDoctor!.name,
        specialty: _selectedDoctor!.specialty,
        patientName: _nameController.text.trim(),
        date: _dateController.text,
        time: _selectedTime!,
        reason: _reasonController.text.trim(),
      ));
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Appointment booked successfully!')),
      );
      Navigator.popUntil(context, ModalRoute.withName(AppRoutes.home));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Book Appointment')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              CustomTextField(
                controller: _nameController,
                label: 'Patient Name',
                icon: Icons.person,
                validator: (v) => Validators.required(v, 'Patient name'),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: DropdownButtonFormField<Doctor>(
                  value: _selectedDoctor,
                  isExpanded: true,
                  decoration: const InputDecoration(
                      labelText: 'Select Doctor',
                      prefixIcon: Icon(Icons.medical_services)),
                  items: AppData.doctors
                      .map((d) => DropdownMenuItem(
                          value: d, child: Text('${d.name} (${d.specialty})')))
                      .toList(),
                  onChanged: (d) => setState(() => _selectedDoctor = d),
                  validator: (d) => d == null ? 'Please select a doctor' : null,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: TextFormField(
                  controller: _dateController,
                  readOnly: true,
                  onTap: _pickDate,
                  validator: (v) => Validators.required(v, 'Date'),
                  decoration: const InputDecoration(
                      labelText: 'Appointment Date',
                      prefixIcon: Icon(Icons.calendar_today)),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: DropdownButtonFormField<String>(
                  value: _selectedTime,
                  decoration: const InputDecoration(
                      labelText: 'Time Slot', prefixIcon: Icon(Icons.access_time)),
                  items: AppData.timeSlots
                      .map((t) => DropdownMenuItem(value: t, child: Text(t)))
                      .toList(),
                  onChanged: (t) => setState(() => _selectedTime = t),
                  validator: (t) => t == null ? 'Please select a time' : null,
                ),
              ),
              CustomTextField(
                controller: _reasonController,
                label: 'Reason for visit',
                icon: Icons.notes,
                maxLines: 3,
                validator: (v) {
                  if (v == null || v.trim().length < 5) {
                    return 'Please describe the reason (min 5 characters)';
                  }
                  return null;
                },
              ),
              CustomButton(
                label: 'Confirm Booking',
                icon: Icons.check,
                onPressed: _submit,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
