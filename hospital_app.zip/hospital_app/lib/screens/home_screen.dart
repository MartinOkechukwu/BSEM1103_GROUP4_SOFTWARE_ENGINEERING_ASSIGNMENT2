import 'package:flutter/material.dart';
import '../data/dummy_data.dart';
import '../routes/app_routes.dart';
import '../utils/theme.dart';
import '../widgets/service_tile.dart';

class HomeScreen extends StatelessWidget {
  final void Function(int) onChangeTab;
  const HomeScreen({super.key, required this.onChangeTab});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: Image.network(
            'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800',
            height: 150,
            width: double.infinity,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(
              height: 150,
              color: AppTheme.primary,
              child: const Center(
                child: Icon(Icons.local_hospital, size: 70, color: Colors.white),
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
        const Text('Hello, Martin 👋',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const Text('How can we help you today?'),
        const SizedBox(height: 16),
        const Text('Next Appointment',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        ValueListenableBuilder(
          valueListenable: AppData.appointments,
          builder: (context, list, _) {
            final upcoming = list.where((a) => a.status == 'Upcoming').toList();
            if (upcoming.isEmpty) {
              return const Card(
                child: ListTile(
                  leading: Icon(Icons.event_busy),
                  title: Text('No upcoming appointments'),
                ),
              );
            }
            final a = upcoming.first;
            return Card(
              color: AppTheme.primary,
              child: ListTile(
                leading: const Icon(Icons.event, color: Colors.white),
                title: Text(a.doctorName, style: const TextStyle(color: Colors.white)),
                subtitle: Text('${a.date} • ${a.time}',
                    style: const TextStyle(color: Colors.white70)),
                trailing: const Icon(Icons.chevron_right, color: Colors.white),
                onTap: () => onChangeTab(2),
              ),
            );
          },
        ),
        const SizedBox(height: 12),
        const Text('Services',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        GridView.count(
          crossAxisCount: 3,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 8,
          crossAxisSpacing: 8,
          children: [
            ServiceTile(
              icon: Icons.person_search,
              label: 'Find Doctor',
              onTap: () => onChangeTab(1),
            ),
            ServiceTile(
              icon: Icons.add_box,
              label: 'Book',
              onTap: () => Navigator.pushNamed(context, AppRoutes.bookAppointment),
            ),
            ServiceTile(
              icon: Icons.folder_shared,
              label: 'Records',
              onTap: () => Navigator.pushNamed(context, AppRoutes.records),
            ),
            ServiceTile(
              icon: Icons.apartment,
              label: 'Departments',
              onTap: () => Navigator.pushNamed(context, AppRoutes.departments),
            ),
            ServiceTile(
              icon: Icons.emergency,
              label: 'Emergency',
              onTap: () => Navigator.pushNamed(context, AppRoutes.emergency),
            ),
            ServiceTile(
              icon: Icons.settings,
              label: 'Settings',
              onTap: () => Navigator.pushNamed(context, AppRoutes.settings),
            ),
          ],
        ),
      ],
    );
  }
}
