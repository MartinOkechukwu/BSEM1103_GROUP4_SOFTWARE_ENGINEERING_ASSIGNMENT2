import 'package:flutter/material.dart';
import '../data/dummy_data.dart';
import '../utils/theme.dart';

/// Medical records with TabBar navigation (Prescriptions / Lab Results).
class RecordsScreen extends StatelessWidget {
  const RecordsScreen({super.key});

  Widget _list(List<Map<String, String>> items, IconData icon) {
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: items.length,
      itemBuilder: (context, i) => Card(
        child: ListTile(
          leading: Icon(icon, color: AppTheme.primary),
          title: Text(items[i]['title']!),
          subtitle: Text(items[i]['detail']!),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Medical Records'),
          bottom: const TabBar(
            indicatorColor: Colors.white,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            tabs: [
              Tab(icon: Icon(Icons.medication), text: 'Prescriptions'),
              Tab(icon: Icon(Icons.science), text: 'Lab Results'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _list(AppData.prescriptions, Icons.medication),
            _list(AppData.labResults, Icons.science),
          ],
        ),
      ),
    );
  }
}
