import 'package:flutter/material.dart';
import '../routes/app_routes.dart';
import '../utils/theme.dart';
import '../widgets/custom_button.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Center(
          child: CircleAvatar(
            radius: 50,
            backgroundColor: AppTheme.primary,
            child: Icon(Icons.person, size: 60, color: Colors.white),
          ),
        ),
        const SizedBox(height: 12),
        const Center(
          child: Text('Martin',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        ),
        const Center(child: Text('Patient ID: CC-2026-001')),
        const SizedBox(height: 16),
        const Card(
          child: Column(
            children: [
              ListTile(leading: Icon(Icons.email), title: Text('martin@email.com')),
              ListTile(leading: Icon(Icons.phone), title: Text('+232 76 000 000')),
              ListTile(leading: Icon(Icons.location_on), title: Text('Freetown, Sierra Leone')),
              ListTile(leading: Icon(Icons.bloodtype), title: Text('Blood Group: O+')),
            ],
          ),
        ),
        const SizedBox(height: 8),
        ListTile(
          leading: const Icon(Icons.folder_shared),
          title: const Text('Medical Records'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.pushNamed(context, AppRoutes.records),
        ),
        const SizedBox(height: 12),
        CustomButton(
          label: 'Edit Profile',
          icon: Icons.edit,
          onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Edit profile coming soon')),
          ),
        ),
        const SizedBox(height: 10),
        CustomButton(
          label: 'Logout',
          icon: Icons.logout,
          color: Colors.red,
          onPressed: () => Navigator.pushNamedAndRemoveUntil(
              context, AppRoutes.login, (route) => false),
        ),
      ],
    );
  }
}
