import 'package:flutter/material.dart';
import '../data/dummy_data.dart';
import '../widgets/service_tile.dart';

class DepartmentsScreen extends StatelessWidget {
  const DepartmentsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final depts = AppData.departments;
    return Scaffold(
      appBar: AppBar(title: const Text('Departments')),
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
        ),
        itemCount: depts.length,
        itemBuilder: (context, i) => ServiceTile(
          icon: depts[i]['icon'] as IconData,
          label: depts[i]['name'] as String,
          onTap: () => ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('${depts[i]['name']} department')),
          ),
        ),
      ),
    );
  }
}
