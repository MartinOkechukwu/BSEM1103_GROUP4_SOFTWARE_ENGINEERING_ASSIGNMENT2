import 'package:flutter/material.dart';
import '../models/appointment.dart';

/// Reusable card for one appointment, with optional cancel button.
class AppointmentCard extends StatelessWidget {
  final Appointment appointment;
  final VoidCallback? onCancel;

  const AppointmentCard({super.key, required this.appointment, this.onCancel});

  Color get _statusColor {
    switch (appointment.status) {
      case 'Completed':
        return Colors.green;
      case 'Cancelled':
        return Colors.red;
      default:
        return Colors.orange;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(appointment.doctorName,
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                ),
                Chip(
                  label: Text(appointment.status,
                      style: const TextStyle(color: Colors.white, fontSize: 12)),
                  backgroundColor: _statusColor,
                ),
              ],
            ),
            Text(appointment.specialty, style: const TextStyle(color: Colors.grey)),
            const SizedBox(height: 8),
            Row(children: [
              const Icon(Icons.calendar_today, size: 16),
              const SizedBox(width: 6),
              Text('${appointment.date}  ${appointment.time}'),
            ]),
            const SizedBox(height: 4),
            Text('Reason: ${appointment.reason}'),
            if (onCancel != null && appointment.status == 'Upcoming')
              Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  onPressed: onCancel,
                  icon: const Icon(Icons.cancel, color: Colors.red),
                  label: const Text('Cancel', style: TextStyle(color: Colors.red)),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
