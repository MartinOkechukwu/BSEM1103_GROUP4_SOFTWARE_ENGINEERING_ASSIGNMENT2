import 'package:flutter/material.dart';
import '../routes/app_routes.dart';
import '../utils/theme.dart';

/// Navigation drawer shared by the main shell.
class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  void _go(BuildContext context, String route) {
    Navigator.pop(context); // close drawer
    Navigator.pushNamed(context, route);
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          const UserAccountsDrawerHeader(
            decoration: BoxDecoration(color: AppTheme.primary),
            accountName: Text('Martin'),
            accountEmail: Text('martin@email.com'),
            currentAccountPicture: CircleAvatar(
              backgroundColor: Colors.white,
              child: Icon(Icons.person, size: 40, color: AppTheme.primary),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.folder_shared),
            title: const Text('Medical Records'),
            onTap: () => _go(context, AppRoutes.records),
          ),
          ListTile(
            leading: const Icon(Icons.apartment),
            title: const Text('Departments'),
            onTap: () => _go(context, AppRoutes.departments),
          ),
          ListTile(
            leading: const Icon(Icons.emergency, color: Colors.red),
            title: const Text('Emergency'),
            onTap: () => _go(context, AppRoutes.emergency),
          ),
          ListTile(
            leading: const Icon(Icons.settings),
            title: const Text('Settings'),
            onTap: () => _go(context, AppRoutes.settings),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.logout),
            title: const Text('Logout'),
            onTap: () => Navigator.pushNamedAndRemoveUntil(
                context, AppRoutes.login, (route) => false),
          ),
        ],
      ),
    );
  }
}
