class Appointment {
  final String doctorName;
  final String specialty;
  final String patientName;
  final String date;
  final String time;
  final String reason;
  final String status; // Upcoming, Completed, Cancelled

  const Appointment({
    required this.doctorName,
    required this.specialty,
    required this.patientName,
    required this.date,
    required this.time,
    required this.reason,
    this.status = 'Upcoming',
  });

  Appointment copyWith({String? status}) => Appointment(
        doctorName: doctorName,
        specialty: specialty,
        patientName: patientName,
        date: date,
        time: time,
        reason: reason,
        status: status ?? this.status,
      );
}
