class Doctor {
  final String name;
  final String specialty;
  final int experienceYears;
  final double rating;
  final String bio;
  final String imageUrl;

  const Doctor({
    required this.name,
    required this.specialty,
    required this.experienceYears,
    required this.rating,
    required this.bio,
    required this.imageUrl,
  });
}
